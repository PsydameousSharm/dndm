import math
from importlib.resources import files
def data_calc(char):
    # Inspiration, Proficiency, armor, initiative, spd, hp, traits, svng throws
    #skills, perception, hit dice, attacks, weapons, tools, spells, features/traits
    #Languages/proficiencies
    #Gold, XP points, appearence,
    if char["starter"] == "g":
        pass
    return None
    
