This is a very early release of list of dnd tools.
These are the following commands:

Roll a dice: roll <dice_number> [repeat]

Change the save path: svc <path>

Create a character: chr

Please note that the chr command will walk you through the character setup. To avoid errors, please try to not use spaces when entering information(asides from the character name).

Please report any errors to psydameousharm@gmail.com